Haoyi Shi
5749038
shi00317@umn.edu
For the cross-validation, I am using the given python script which using Scikit-Learn MSE and Accuracy_Score